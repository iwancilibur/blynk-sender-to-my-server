## Please take a look at:
[Blynk Firmware documentation](http://docs.blynk.cc/#blynk-firmware)  
[Blynk Help Center](http://help.blynk.cc)
